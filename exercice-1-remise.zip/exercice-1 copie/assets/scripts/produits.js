const produits = {
    livres: [
        {
            titre: 'J\'ai faim&thinsp;!',
            sujet: 'Littérature jeunesse',
            prix: 10,
            rabais: false,
            auteur: 'Élise Gravel',
            editeur: 'Courte Échelle',
            pages: 30
        },
        {
            titre: 'Bonsoir petit renard',
            sujet: 'Enfants - 2 a 7 ans',
            prix: 25,
            rabais: 15,
            auteur: 'Stuart Lynch',
            editeur: '1.2.3 Soleil',
            pages: 10
        },
        {
            titre: 'Si j\'étais un crabe',
            sujet: 'Enfants - 2 a 7 ans',
            prix: 15,
            rabais: false,
            auteur: 'Mathieu Fortin',
            editeur: 'Petits génies',
            pages: 10
        } 
    ],
    jeux: [
        {
            titre: 'Catan',
            sujet: 'Jeux de société',
            prix: 80,
            rabais: 15,
            editeur: 'Filosofia',
        },
        {
            titre: 'Exploding Kittens',
            sujet: 'Jeux de société',
            prix: 35,
            rabais: false,
            editeur: 'Exploding Kittens',
        },
        {
            titre: 'Une patate à vélo le jeu',
            sujet: 'Jeux de société',
            prix: 30,
            rabais: false,
            editeur: 'Randolph',
        }
    ]
}